import json
import botocore
import boto3
import logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
  try:
    response = {}
    Iteration = event['Iteration']
    logger.info('Clean >> Starting...')
    clean_up()
    if check():
        response = {"statusCode": 200,"Message": "Succesful", "Iteration": Iteration, "Stopped": 1}
        logger.info('Clean >> All resources are stopped')
    else:
        response = {"statusCode": 200,"Message": "Succesful", "Iteration": Iteration, "Stopped": 0}
        logger.info('Clean >> Resources are still running...')
    report = " Report: \n"+ec2_report() + "\n" + rds_intances() + "\n" + rds_cluster() + "\n" + sm_instances()
    response['Message'] = report
    response['LogGroupName'] = context.log_group_name
    response['LogStreamName'] = context.log_stream_name
    return response
  except Exception as e:
    logger.info('Error while executing Cleaning: '+str(e))
    response = {"statusCode": 500,"Message": str(e), "Iteration": event['Iteration']}
    return response

def clean_up():
    try:
        # Cleaning Clusters
        clusters = listing_rds_cluster('available')
        if len(clusters) > 0:
            logger.info('Cleaning >> Stopping RDS Aurora Clusters')
            stopping_rds_clusters(clusters)

        # Cleaning EC2...
        ec2s = listing_ec2(['pending', 'running'])
        if len(ec2s) > 0:
            logger.info('Cleaning >> Stopping EC2 Instances')
            stopping_ec2(ec2s)

        # Cleaning RDS
        rdss = listing_rds('available')
        if len(rdss) > 0:
            logger.info('Cleaning >> Stopping RDS Instances')
            stopping_rds(rdss)
        
        # Cleaning Sage Maker
        sms = listing_sm('InService')
        if len(sms) > 0:
            logger.info('Cleaning >> Stopping Sage Maker Instances')
            stopping_sm(sms)

    except Exception as e:
        logger.info('Error while executing Cleaning: '+str(e))

def check():
    try:
        # checking instances status..
        return check_ec2_stopped() and check_rds_clusters() and check_rds_stopped() and check_sm_stopped()
    except Exception as e:
        logger.info('Error while executing Check: '+str(e))

def listing_ec2(ec2_states):
  try:
    instances = []
    ec2 = boto3.client('ec2')
    ec2_result = ec2.describe_instances(Filters=[{'Name':'instance-state-name','Values':ec2_states}])
    for reservation in ec2_result['Reservations']:
      for instance in reservation['Instances']:
        instances.append(instance['InstanceId'])
    #instances = ['i-037c369dd9b7510ec', 'i-070b04d8f0f9f680c','i-0aaf513951e58821b']
    return instances
  except botocore.exceptions.ClientError as e:
    logger.info('Cleaning >> Error Listing EC2 Instances: '+str(e.response['Error']['Message']))
    return []

def stopping_ec2(instances):
  try:
    ec2 = boto3.client('ec2')
    for instance in instances:
      try:
        result = ec2.stop_instances(InstanceIds=[instance])
        logger.info('Cleaning >> Stopping EC2 Instance: '+str(instance))
      except botocore.exceptions.ClientError as err:
        logger.info('Cleaning >> Error Stopping ec2 Instance '+str(instance)+': '+err.response['Error']['Message'])
  except botocore.exceptions.ClientError as e:
    logger.info('Cleaning >> Error Stopping EC2 Instances: '+str(e.response['Error']['Message']))

def listing_rds(status):
  try:
    instances = []
    rds = boto3.client('rds')
    rds_result = rds.describe_db_instances()
    for rdsi in rds_result['DBInstances']:
      if rdsi['DBInstanceStatus'] == 'available':
        instances.append(rdsi['DBInstanceIdentifier'])
    #instances = ['test-lambda-rc3', 'test-lambda-rc5']
    return instances
  except botocore.exceptions.ClientError as err:
    logger.info('Cleaning >> Error Listing RDS Instances: '+str(err.response['Error']['Message']))
    return []

def stopping_rds(instances):
  try:
    rds = boto3.client('rds')
    for instance in instances:
      try:
        rds.stop_db_instance(DBInstanceIdentifier=instance)
        logger.info('Cleaning >> Stopping RDS Instance: '+instance)
      except botocore.exceptions.ClientError as e:
        logger.info('Cleaning >> Error Stopping RDS Instance '+str(instance)+': '+e.response['Error']['Message'])
  except botocore.exceptions.ClientError as err:
    logger.info('Cleaning >> Error Stopping RDS Instances: '+str(err.response['Error']['Message']))

def listing_sm(status):
  try:
    instances = []
    sage = boto3.client('sagemaker')
    sage_result_service = sage.list_notebook_instances(StatusEquals=status)
    for n_insta in sage_result_service['NotebookInstances']:
      instances.append(n_insta['NotebookInstanceName'])
    #instances = ['test-lambda-rc6', 'test-lambda-rc4']
    return instances
  except botocore.exceptions.ClientError as err:
    logger.info('Cleaning >> Error stopping Sage Maker Instances: '+str(err.response['Error']['Message']))
    return []

def stopping_sm(instances):
  try:
    sage = boto3.client('sagemaker')
    for instance in instances:
      try:
        sage.stop_notebook_instance(NotebookInstanceName=instance)
        logger.info('Cleaning >> Stopping Sage Maker Instance: '+instance)
      except botocore.exceptions.ClientError as e:
        logger.info('Cleaning >> Error Stopping Sage Maker Instance: '+instance+" : "+str(e.response['Error']['Message']))
  except botocore.exceptions.ClientError as err:
    logger.info('Cleaning >> Error stopping Sage Maker Instances: '+str(err.response['Error']['Message']))

def listing_rds_cluster(status):
  try:
    clusters = []
    rds = boto3.client('rds')
    cluster_result = rds.describe_db_clusters()
    for cluster in cluster_result['DBClusters']:
      if cluster['Status'] == status:
        clusters.append(cluster['DBClusterIdentifier'])
    #clusters = ['test-lambda-cluster']
    return clusters
  except botocore.exceptions.ClientError as err:
    logger.info('Cleaning >> Error Listing RDS Clusters: '+str(err.response['Error']['Message']))
    return []

def stopping_rds_clusters(clusters):
  try:
    rds = boto3.client('rds')
    for cluster in clusters:
      try:
        rds.stop_db_cluster(DBClusterIdentifier=cluster)
        logger.info('Cleaning >> Stopping RDS Cluster: '+cluster)
      except botocore.exceptions.ClientError as e:
        logger.info('Cleaning >> Error Stopping RDS Cluster '+str(cluster)+': '+e.response['Error']['Message'])
  except botocore.exceptions.ClientError as err:
    logger.info('Cleaning >> Error Stopping RDS Clusters: '+str(err.response['Error']['Message']))

def check_ec2_stopped():    
  try:
    logger.info('Cleaning >> Checking EC2 Instances State... ')
    ec2 = boto3.client('ec2')
    ec2_result = ec2.describe_instances()
    for reservation in ec2_result['Reservations']:
      for instance in reservation['Instances']:
        if instance['State']['Name'] != 'stopped' and instance['State']['Name'] != 'terminated':
            logger.info('Cleaning >> EC2 Instance '+instance['InstanceId']+' in '+str(instance['State']['Name'])+' status...')
            return False
    return True
  except botocore.exceptions.ClientError as err:
    logger.info('Cleaning >> Error Checking all EC2 Instances: '+str(err.response['Error']['Message']))
    return False

def check_rds_stopped():
  try:
    logger.info('Cleaning >> Checking RDS Instances State... ')
    rds = boto3.client('rds')
    rds_result = rds.describe_db_instances()
    for rdsi in rds_result['DBInstances']:
      if rdsi['DBInstanceStatus'] != 'stopped':
          logger.info('Cleaning >> RDS Instance '+rdsi['DBInstanceIdentifier']+' in '+rdsi['DBInstanceStatus']+' status...')
          return False
    return True
  except botocore.exceptions.ClientError as err:
    logger.info('Cleaning >> Error Checking all RDS Instances: '+str(err.response['Error']['Message']))
    return False

def check_sm_stopped():
  try:
    logger.info('Cleaning >> Checking Sage Maker Instances State... ')
    sage = boto3.client('sagemaker')
    sage_result_service = sage.list_notebook_instances()
    for n_insta in sage_result_service['NotebookInstances']:
      if n_insta['NotebookInstanceStatus'] != 'Stopped':
          logger.info('Cleaning >> Sagemaker Instance '+n_insta['NotebookInstanceName']+' in '+n_insta['NotebookInstanceStatus']+' status...')
          return False
    return True
  except botocore.exceptions.ClientError as err:
    logger.info('Cleaning >> Error Checking all SM Instances: '+str(err.response['Error']['Message']))
    return False

def check_rds_clusters():
  try:
    logger.info('Cleaning >> Checking RDS Clusters State... ')
    rds = boto3.client('rds')
    cluster_result = rds.describe_db_clusters()
    for cluster in cluster_result['DBClusters']:
      if cluster['Status'] != 'stopped':
          logger.info('Cleaning >> RDS Aurora Cluster '+cluster['DBClusterIdentifier']+' in '+cluster['Status'] +' status...')
          return False
    return True
  except botocore.exceptions.ClientError as err:
    logger.info('Cleaning >> Error Checking all RDS Clusters: '+str(err.response['Error']['Message']))
    return False

def ec2_report():
  try:
    ec2 = boto3.client('ec2')
    ec2_result = ec2.describe_instances()
    stopped = " - Stopped: \n"
    non_stopped = "- Non Stopped: \n"
    for reservation in ec2_result['Reservations']:
      for instance in reservation['Instances']:
        if instance['State']['Name'] == 'stopped':
          stopped += " * EC2 Instance "+instance['InstanceId']+"\n"
        elif instance['State']['Name'] != 'terminated':
          non_stopped += " * EC2 Instance "+instance['InstanceId']+" | Status: "+instance['State']['Name'] + "\n"
    res = "---------- EC2 Instances ----------\n" + stopped + ""+ non_stopped+"\n"
    return res
  except botocore.exceptions.ClientError as e:
    logger.info('Cleaning >> Error while Reporting EC2: '+str(e.response['Error']['Message']))
    return ""

def rds_intances():
  try:
    rds = boto3.client('rds')
    stopped = " - Stopped: \n"
    non_stopped = "- Non Stopped: \n"
    rds_result = rds.describe_db_instances()
    for rdsi in rds_result['DBInstances']:
      if rdsi['DBInstanceStatus'] == 'stopped':
        stopped += " * RDS Instance "+rdsi['DBInstanceIdentifier']+"\n"
      else:
        non_stopped += " * RDS Instance "+rdsi['DBInstanceIdentifier']+" | Status: "+rdsi['DBInstanceStatus']+"\n"
    res = "---------- RDS Instances ----------\n" + stopped + ""+ non_stopped+"\n"
    return res
  except botocore.exceptions.ClientError as err:
    logger.info('Cleaning >> Error while Reporting RDS: '+str(err.response['Error']['Message']))
    return ""

def rds_cluster():
  try:
    rds = boto3.client('rds')
    stopped = " - Stopped: \n"
    non_stopped = "- Non Stopped: \n"
    cluster_result = rds.describe_db_clusters()
    for cluster in cluster_result['DBClusters']:
      if cluster['Status'] == 'stopped':
        stopped += " * RDS Cluster "+cluster['DBClusterIdentifier']+"\n"
      else:
        non_stopped += " * RDS Cluser "+cluster['DBClusterIdentifier']+" | Status: "+cluster['Status']+"\n"
    res = "---------- RDS Clusters ----------\n" + stopped + ""+ non_stopped+"\n"
    return res
  except botocore.exceptions.ClientError as err:
    logger.info('Cleaning >> Error while Reporting RDS Cluster: '+str(err.response['Error']['Message']))
    return ""

def sm_instances():
  try:
    sage = boto3.client('sagemaker')
    stopped = " - Stopped: \n"
    non_stopped = "- Non Stopped: \n"
    sage_result_service = sage.list_notebook_instances()
    for n_insta in sage_result_service['NotebookInstances']:
      if n_insta['NotebookInstanceStatus'] == 'Stopped':
        stopped += " * Sage Make Instance: "+n_insta['NotebookInstanceName']+"\n"
      else:
        non_stopped += " * Sage Maker Instance "+n_insta['NotebookInstanceName']+" | Status: "+n_insta['NotebookInstanceStatus']+"\n"
    res = "---------- Sagemaker Instances ----------\n" + stopped + ""+ non_stopped+"\n"
    return res
  except botocore.exceptions.ClientError as err:
    logger.info('Cleaning >> Error while Reporting Sage Maker Intances: '+str(err.response['Error']['Message']))
    return ""